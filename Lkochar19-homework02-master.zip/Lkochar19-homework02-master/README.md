# Lkochar19-homework02
homework02 created for Lkochar19

Homework 2 Lucy Kocharian
